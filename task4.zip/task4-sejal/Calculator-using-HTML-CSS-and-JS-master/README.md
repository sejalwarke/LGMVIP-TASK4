# Calculator-using-HTML-CSS-and-JS


>This Repositary contains three files: 



* calcindex.html

* calcscript.js

* calcstyle.css



The style sheet contains the necessary stylings and the calcscript file contains the necessary functions to implement the calculator.
